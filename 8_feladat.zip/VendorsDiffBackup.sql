BACKUP DATABASE [Vendors] TO  DISK = N'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\Backup\VendorsDiffBackup.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'Vendors-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO
